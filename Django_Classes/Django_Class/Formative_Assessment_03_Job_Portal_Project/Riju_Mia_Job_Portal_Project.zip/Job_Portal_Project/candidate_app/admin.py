from django.contrib import admin
from candidate_app.models import*

# Register your models here.
admin.site.register(CandidateProfileModel)