from django.contrib import admin
from employer_app.models import *

# Register your models here.
admin.site.register(EmployerProfileModel)
admin.site.register(JobModel)
